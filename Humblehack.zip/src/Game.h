#include "PMemory.h"
#include "Decrypt.h"

#include <windows.h>
#include <TlHelp32.h>
#include <cstdio>
#include <windows.h>
#include <conio.h>
#include <FCNTL.H>
#include <io.h>
#include <iostream>
#include <fstream>
#include <thread>
#include <string>
#include <sstream>
#include <random>
#include <vector>
#include <algorithm>
#include <stdint.h>
#include <math.h>  
#include <time.h>

#include <gl/GL.h>
#include <gl/GLU.h>
#pragma comment (lib, "opengl32.lib")
#pragma comment (lib, "glu32.lib")
#include <dwmapi.h>
#pragma comment(lib, "Dwmapi.lib")

#define WIN32_LEAN_AND_MEAN 
using namespace std;

struct GlowObjectDefinition_t
{
	DWORD pEntity;
	float r;
	float g;
	float b;
	float a;
	uint8_t unk1[16];
	bool m_bRenderWhenOccluded;
	bool m_bRenderWhenUnoccluded;
	bool m_bFullBloom;
	uint8_t unk2[10];
};

struct Player {
	[swap_lines]
	DWORD dwBase;
	int team;
	[/swap_lines]
};