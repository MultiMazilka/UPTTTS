#include "Game.h"
#define caseStringify(x) case x: return std::string(#x)
#define CStringify(x) std::to_string(x).c_str()

PModule modEngine, modClient;
PMemory mem;

HANDLE TargetProcess;
DWORD DwClient;
DWORD DwEngine;

RECT m_Rect; 
RECT c_Rect; 
float SWidth;
float SHeight;
HWND GameHWND;
HWND EspHWND;
HINSTANCE CurrentInstance;
HDC MainHDC;
HGLRC MainHGLRC;
HPALETTE MainPalette;
LPCSTR WName = "Humblehack Overlay";

typedef struct{
	float flMatrix [4][4];
}WorldToScreenMatrix_t;

WorldToScreenMatrix_t W2S_M;



DWORD DwEntityList;
DWORD DwEnginePointer = 0x005C22C4;
DWORD DwLocalPlayer;
DWORD DwViewAngle = 0x4D0C;
DWORD DwGlow;
DWORD DwViewMatrix = 0x04AA2B34; // 63 строка (могут быть проблемы)



const DWORD DwCrosshairId = 0xAA64; // 49 строка
const DWORD DwVecViewOrigin = 0x104; // 44 строка
const DWORD DwVecOrigin = 0x134; // 18 строка
const DWORD DwVecPunch = 0x301C; // 48 строка
const DWORD DwTeamNumber = 0xF0; // 19 строка
const DWORD DwShotsFired = 0xA2C0; // 27 строка
const DWORD DwBoneMatrix = 0x2698; // 52 строка
const DWORD DwEntitySize = 0x10;
const DWORD DwHealth = 0xFC;
const DWORD DwLifeState = 0x25B;
const DWORD DwVecVelocity = 0x110;
const DWORD DwIsDormant = 0xE9;
const DWORD DwFlash = 0xA308;
const DWORD DwSpotted = 0x939;

float PitchMinPunch;
float PitchMaxPunch;
float YawMinPunch;
float YawMaxPunch;
float SmoothAmount;
float glowThickness;
int TriggerDelay;
int TargetBone;


bool glowEnabled = false;
bool aimEnabled = false;
bool radarEnabled = false;
bool rcsEnabled = false;
bool triggerEnabled = true;
bool autoTriggerEnabled = false;
bool ThreadPaused = false; 
bool TriggerThreadPaused = false;
bool isDormantCheck = false;
bool bhopEnabled = false;
bool showTeam = true;

DWORD yesKey = 89;

DWORD TrigVkeyCode;
DWORD ToggleTrigVkeyCode;
DWORD ForceAimVkeyCode;
DWORD ESPVkeyCode;
DWORD PanicVkeyCode;
DWORD RadarVkeyCode;
DWORD AimVkeyCode;
DWORD enableBhop;
DWORD bhopVkeyCode;
DWORD jumpKey;
DWORD enableExternal;
DWORD RCSVkeyCode;

DWORD jumpScanCode = 57;
DWORD NewAimVkeyCode = 1;

int prevFired = 0;
float oldAng[2];
float viewAng[2];

[junk_enable /]
[enc_string_enable /]

struct Vec3_t
{
    float x;
    float y;
    float z;
};

struct
{
	DWORD GetBaseEntity(int PlayerNumber)
	{
		return mem.Read<DWORD>(DwClient + DwEntityList + (DwEntitySize * PlayerNumber));
	}
	
	void GetPosition(int PlayerNumber, float* Position)
	{
		DWORD BaseEntity = GetBaseEntity(PlayerNumber);
		mem.Read<float*>(BaseEntity + DwVecOrigin, true, 3, Position);
	}

	bool IsDead(int PlayerNumber)
	{
		DWORD BaseEntity = GetBaseEntity(PlayerNumber);
		return mem.Read<bool>(BaseEntity + DwLifeState);	
	}

	bool IsDormant(int PlayerNumber)
	{
		DWORD BaseEntity = GetBaseEntity(PlayerNumber);
		return mem.Read<bool>(BaseEntity + DwIsDormant);	
	}

	int GetTeam(int PlayerNumber)
	{
		DWORD BaseEntity = GetBaseEntity(PlayerNumber);
		return mem.Read<int>(BaseEntity + DwTeamNumber);
	}
	
	int GetFlash(int PlayerNumber)
	{
		DWORD BaseEntity = GetBaseEntity(PlayerNumber);
		return mem.Read<int>(BaseEntity + DwFlash);	
	}
	
	int GetHealth(int PlayerNumber)
	{
		DWORD BaseEntity = GetBaseEntity(PlayerNumber);
		return mem.Read<int>(BaseEntity + DwHealth);
	}

	void GetVelocity(int PlayerNumber, float* Buffer)
	{
		DWORD BaseEntity = GetBaseEntity(PlayerNumber);
		mem.Read<float*>(BaseEntity + DwVecVelocity, true, 3, Buffer);
	}

	void GetBonePosition(int PlayerNumber, float* BonePosition)
	{
		DWORD BaseEntity = GetBaseEntity(PlayerNumber);
		DWORD BoneMatrix = mem.Read<DWORD>(BaseEntity + DwBoneMatrix);
		mem.Read<float*>(BoneMatrix + 0x30 * TargetBone + 0x0C, true, 1, &BonePosition[0]);
		mem.Read<float*>(BoneMatrix + 0x30 * TargetBone + 0x1C, true, 1, &BonePosition[1]);
		mem.Read<float*>(BoneMatrix + 0x30 * TargetBone + 0x2C, true, 1, &BonePosition[2]);
	}

}EntityList;

struct
{

	DWORD GetPlayerBase()
	{
		return mem.Read<DWORD>(DwClient + DwLocalPlayer);
	}

	void SetAngles(float* Angles)
	{
		DWORD AnglePointer = mem.Read<DWORD>(DwEngine + DwEnginePointer);
		mem.Write<float*>(AnglePointer + DwViewAngle, Angles, true, 3);
	}

	void GetVelocity(float* Buffer)
	{
		DWORD PlayerBase = GetPlayerBase();
		mem.Read<float*>(PlayerBase + DwVecVelocity, true, 3, Buffer);
	}
	
	float GetZVelocity()
	{
		DWORD PlayerBase = GetPlayerBase();
		float Velocity[3];
		mem.Read<float*>(PlayerBase + DwVecVelocity, true, 3, Velocity);
		return Velocity[2];
	}

	void GetAngles(float* Angles)
	{
		DWORD AnglePointer = mem.Read<DWORD>(DwEngine + DwEnginePointer);
		mem.Read<float*>(AnglePointer + DwViewAngle, true, 3, Angles);
	}
	
	int GetJumping()
	{
		DWORD PlayerBase = GetPlayerBase();
		return mem.Read<int>(0x0635076C);
	}

	int GetTeam()
	{
		DWORD PlayerBase = GetPlayerBase();
		return mem.Read<int>(PlayerBase + DwTeamNumber);
	}

	int GetCrosshairId()
	{
		DWORD PlayerBase = GetPlayerBase();
		return mem.Read<int>(PlayerBase + DwCrosshairId) - 1;	
	}

	void GetPunch(float* Punch)
	{
		DWORD PlayerBase = GetPlayerBase();
		mem.Read<float*>(PlayerBase + DwVecPunch, true, 2, Punch);
	}
	
	Vec3_t GetPunch1()
	{
		DWORD PlayerBase = GetPlayerBase();
		return mem.ReadTwo<Vec3_t>(PlayerBase + DwVecPunch);
	}

	float GetViewOrigin()
	{
		DWORD PlayerBase = GetPlayerBase();
		float Vecview[3];
		mem.Read<float*>(PlayerBase + DwVecViewOrigin, true, 3, Vecview);
		return Vecview[2];
	}

	void GetPosition(float* Position)
	{
		DWORD PlayerBase = GetPlayerBase();
		mem.Read<float*>(PlayerBase + DwVecOrigin, true, 3, Position);
	}

	int GetShotsFired()
	{
		DWORD PlayerBase = GetPlayerBase();
		return mem.Read<int>(PlayerBase + DwShotsFired);	
	}

}NewPlayer;

float Get3D(float X, float Y, float Z, float eX, float eY, float eZ)	
{
	return(sqrtf( (eX - X) * (eX - X) + (eY - Y) * (eY - Y) + (eZ - Z) * (eZ - Z)));
}

void ResizeWindow()
{
	SWidth = c_Rect.right - c_Rect.left;
	SHeight = c_Rect.bottom - c_Rect.top;
	SetWindowPos(EspHWND, 0, m_Rect.left, m_Rect.bottom - SHeight, SWidth, SHeight, 0);
	glViewport(m_Rect.left, m_Rect.top, SWidth, SHeight);
	glOrtho(c_Rect.left, c_Rect.right, c_Rect.bottom, c_Rect.top, 0, 1);
}

void Initiate()
{
	GameHWND = NULL;
	while (!GameHWND)
	{
		GameHWND = FindWindow(0, "Counter-Strike: Global Offensive");
		Sleep(100);
	}
	CurrentInstance = GetModuleHandle(NULL);
	ResizeWindow();
}

void SetupGL()
{
	PIXELFORMATDESCRIPTOR pfd = {
		sizeof(PIXELFORMATDESCRIPTOR),
		1,                                  // Version Number
		PFD_DRAW_TO_WINDOW |              // Format Must Support Window
		PFD_SUPPORT_OPENGL |              // Format Must Support OpenGL
		PFD_SUPPORT_COMPOSITION |         // Format Must Support Composition
		PFD_DOUBLEBUFFER,                 // Must Support Double Buffering
		PFD_TYPE_RGBA,                    // Request An RGBA Format
		32,                               // Select Our Color Depth
		0, 0, 0, 0, 0, 0,                 // Color Bits Ignored
		8,                                // An Alpha Buffer
		0,                                // Shift Bit Ignored
		0,                                // No Accumulation Buffer
		0, 0, 0, 0,                       // Accumulation Bits Ignored
		0,                               // No Z-Buffer (Depth Buffer)
		8,                                // Some Stencil Buffer
		0,                                // No Auxiliary Buffer
		PFD_MAIN_PLANE,                   // Main Drawing Layer
		0,                                // Reserved
		0, 0, 0                           // Layer Masks Ignored
	};
	int PixelFormat = ChoosePixelFormat(MainHDC, &pfd);
	if (!PixelFormat)
	{
		ExitThread(0);
	}
	if (!SetPixelFormat(MainHDC, PixelFormat, &pfd))
	{
		ExitThread(0);
	}
	if (!DescribePixelFormat(MainHDC, PixelFormat, sizeof(PIXELFORMATDESCRIPTOR), &pfd))
	{
		ExitThread(0);
	}
	MainHGLRC = wglCreateContext(MainHDC);
	if (!MainHGLRC)
	{
		ExitThread(0);
	}
	if (!wglMakeCurrent(MainHDC, MainHGLRC))
	{
		ExitThread(0);
	}
	glMatrixMode(GL_PROJECTION);
	ResizeWindow();
	glClearColor(0.f, 0.f, 0.f, 0.f);
}

bool WorldToScreen(float * from, float * to)
{
	WorldToScreenMatrix_t WorldToScreenMatrix;
	WorldToScreenMatrix = mem.ReadTwo<WorldToScreenMatrix_t>(DwClient + DwViewMatrix);
	float w = 0.0f;

	to[0] = WorldToScreenMatrix.flMatrix[0][0] * from[0] + WorldToScreenMatrix.flMatrix[0][1] * from[1] + WorldToScreenMatrix.flMatrix[0][2] * from[2] + WorldToScreenMatrix.flMatrix[0][3];
	to[1] = WorldToScreenMatrix.flMatrix[1][0] * from[0] + WorldToScreenMatrix.flMatrix[1][1] * from[1] + WorldToScreenMatrix.flMatrix[1][2] * from[2] + WorldToScreenMatrix.flMatrix[1][3];
	w = WorldToScreenMatrix.flMatrix[3][0] * from[0] + WorldToScreenMatrix.flMatrix[3][1] * from[1] + WorldToScreenMatrix.flMatrix[3][2] * from[2] + WorldToScreenMatrix.flMatrix[3][3];
	
	if (w < 0.01f)
		return false;

	float invw = 1.0f / w;
	to[0] *= invw;
	to[1] *= invw;

	int width = (int)(m_Rect.right - m_Rect.left);
	int height = (int)(m_Rect.bottom - m_Rect.top);

	float x = width / 2;
	float y = height / 2;

	x += 0.5 * to[0] * width + 0.5;
	y -= 0.5 * to[1] * height + 0.5;

	to[0] = x + m_Rect.left;
	to[1] = y + m_Rect.top;
	
	return true;

}

void ReadData(Player* p) {
	p->team = mem.Read<int>(p->dwBase + DwTeamNumber);
}

void AngleNormalize(float* angle)
{
	if (angle[0] > 89.0f && angle[0] <= 180.0f)
	{
		angle[0] = 89.0f;
	}
	if (angle[0] > 180.f)
	{
		angle[0] -= 360.f;
	}
	if (angle[0] < -89.0f)
	{
		angle[0] = -89.0f;
	}
	if (angle[1] > 180.f)
	{
		angle[1] -= 360.f;
	}
	if (angle[1] < -180.f)
	{
		angle[1] += 360.f;
	}
	if (angle[2] != 0.0f)
	{
		angle[2] = 0.0f;
	}
}

void calcang(float *src, float *dst, float *angles)
{
	random_device Random;
	mt19937 RandomGen(Random());
	uniform_real<float> RandomXdistrib(PitchMinPunch, PitchMaxPunch);
	uniform_real<float> RandomYdistrib(YawMinPunch, YawMaxPunch);
	float MyPunch[2];
	NewPlayer.GetPunch(MyPunch);
	float pitchreduction = RandomXdistrib(RandomGen);
	float yawreduction = RandomYdistrib(RandomGen);
	float delta[3] = { (src[0] - dst[0]), (src[1] - dst[1]), ((src[2] + NewPlayer.GetViewOrigin()) - dst[2]) };
	float hyp = sqrt(delta[0] * delta[0] + delta[1] * delta[1]);
	angles[0] = atanf(delta[2] / hyp) * 57.295779513082f - MyPunch[0] * pitchreduction;
	angles[1] = atanf(delta[1] / delta[0]) * 57.295779513082f - MyPunch[1] * yawreduction;
	angles[2] = 0.0f;
	if (delta[0] >= 0.0)
	{
		angles[1] += 180.0f;
	}
}

void SmoothAngleSet(float* dest, float* orig)
{
	float SmoothAngles[3];
	SmoothAngles[0] = dest[0] - orig[0];
	SmoothAngles[1] = dest[1] - orig[1];
	SmoothAngles[2] = 0.0f;
	AngleNormalize(SmoothAngles);
	SmoothAngles[0] = orig[0] + SmoothAngles[0] / 100.0f * SmoothAmount;
	SmoothAngles[1] = orig[1] + SmoothAngles[1] / 100.0f * SmoothAmount;
	SmoothAngles[2] = 0.0f;
	AngleNormalize(SmoothAngles);
	NewPlayer.SetAngles(SmoothAngles);
	Sleep(1);
}

void Click()
{
	mouse_event(MOUSEEVENTF_LEFTDOWN, NULL, NULL, NULL, NULL);
	Sleep(1);
	mouse_event(MOUSEEVENTF_LEFTUP, NULL, NULL, NULL, NULL);
	Sleep(30);
}

void Space()
{
	keybd_event(jumpKey, jumpScanCode, 0, 0);
	Sleep(1); 
	keybd_event(jumpKey, jumpScanCode, KEYEVENTF_KEYUP, 0);
	Sleep(30);                         
}

void VelocityComp(int PlayerNumber, float* EnemyPos)
{
	float EnemyVelocity[3];
	float MyVelocity[3];
	EntityList.GetVelocity(PlayerNumber, EnemyVelocity);
	NewPlayer.GetVelocity(MyVelocity);
	EnemyPos[0] = EnemyPos[0] + (EnemyVelocity[0] / 100.f) * (40.f / SmoothAmount); 
	EnemyPos[1] = EnemyPos[1] + (EnemyVelocity[1] / 100.f) * (40.f / SmoothAmount);
	EnemyPos[2] = EnemyPos[2] + (EnemyVelocity[2] / 100.f) * (40.f / SmoothAmount);
	EnemyPos[0] = EnemyPos[0] - (MyVelocity[0] / 100.f) * (40.f / SmoothAmount);
	EnemyPos[1] = EnemyPos[1] - (MyVelocity[1] / 100.f) * (40.f / SmoothAmount);
	EnemyPos[2] = EnemyPos[2] - (MyVelocity[2] / 100.f) * (40.f / SmoothAmount);
}

DWORD WINAPI AB(LPVOID params)
{
	cout << "\nAimbot thread is running..." << endl;
	while (!GetAsyncKeyState(PanicVkeyCode))
	{
		Sleep(1);

		if (GetAsyncKeyState(PanicVkeyCode))
		{
			ExitThread(0);
		}
		
		int PlayerNumber = NewPlayer.GetCrosshairId();

		while (GetAsyncKeyState(ForceAimVkeyCode) < 0 && PlayerNumber < 64 && PlayerNumber >= 0 && EntityList.GetTeam(PlayerNumber) != NewPlayer.GetTeam() && EntityList.IsDead(PlayerNumber) != true)
		{
			int TempPlayerNumber = NewPlayer.GetCrosshairId();
			if (TempPlayerNumber < 64 && TempPlayerNumber >= 0 && EntityList.GetTeam(TempPlayerNumber) != NewPlayer.GetTeam() && EntityList.IsDead(TempPlayerNumber) != true)
			{
				PlayerNumber = TempPlayerNumber;
			}
			float PlayerPos[3];
			float EnemyPos[3];
			float AimAngle[3];
			float CurrentAngle[3];
			NewPlayer.GetPosition(PlayerPos);
			EntityList.GetBonePosition(PlayerNumber, EnemyPos);
			VelocityComp(PlayerNumber, EnemyPos);
			calcang(PlayerPos, EnemyPos, AimAngle);
			AngleNormalize(AimAngle);
			NewPlayer.GetAngles(CurrentAngle);
			AngleNormalize(CurrentAngle);
			SmoothAngleSet(AimAngle, CurrentAngle);
				
			Sleep(1);
		}
			
		if (aimEnabled)
		{
			ThreadPaused = false;
			int PlayerNumber = NewPlayer.GetCrosshairId();
				
			while (GetAsyncKeyState(NewAimVkeyCode) < 0 && NewPlayer.GetShotsFired() > 1 &&  PlayerNumber < 64 && PlayerNumber >= 0 && EntityList.GetTeam(PlayerNumber) != NewPlayer.GetTeam() && EntityList.IsDead(PlayerNumber) != true)
			{
				int TempPlayerNumber = NewPlayer.GetCrosshairId();
				if (TempPlayerNumber < 64 && TempPlayerNumber >= 0 && EntityList.GetTeam(TempPlayerNumber) != NewPlayer.GetTeam() && EntityList.IsDead(TempPlayerNumber) != true)
				{
					PlayerNumber = TempPlayerNumber;
				}
				float PlayerPos[3];
				float EnemyPos[3];
				float AimAngle[3];
				float CurrentAngle[3];
				NewPlayer.GetPosition(PlayerPos);
				EntityList.GetBonePosition(PlayerNumber, EnemyPos);
				VelocityComp(PlayerNumber, EnemyPos);
				calcang(PlayerPos, EnemyPos, AimAngle);
				AngleNormalize(AimAngle);
				NewPlayer.GetAngles(CurrentAngle);
				AngleNormalize(CurrentAngle);
				SmoothAngleSet(AimAngle, CurrentAngle);
				Sleep(1);
				
				
			}
			
		}
		else
		{
			ThreadPaused = true;
			Sleep(500);
		}		
	}
}

DWORD WINAPI TB(LPVOID params)
{
	cout << "Trigger thread is running..." << endl;
	while (!GetAsyncKeyState(PanicVkeyCode))
	{
		Sleep(1);

		if (GetAsyncKeyState(PanicVkeyCode))
		{
			ExitThread(0);
		}
		
		if(triggerEnabled)
		{
			int PlayerNumber = NewPlayer.GetCrosshairId();
			if (GetAsyncKeyState(TrigVkeyCode) < 0 && TrigVkeyCode != 1)
			{
				Sleep(TriggerDelay);
				while (NewPlayer.GetCrosshairId() > 0 && GetAsyncKeyState(TrigVkeyCode) < 0 && TrigVkeyCode != 1 && PlayerNumber < 64 && PlayerNumber >= 0 && EntityList.GetTeam(PlayerNumber) != NewPlayer.GetTeam() && EntityList.IsDead(PlayerNumber) != true)
				{
					Click();
					
					if (!aimEnabled && rcsEnabled)
					{
						int shotsFired = NewPlayer.GetShotsFired();
						if (shotsFired > 1 && shotsFired >= prevFired)
						{
							float MyPunch[2];
							NewPlayer.GetPunch(MyPunch);

							float CurrentAngle[2];
							NewPlayer.GetAngles(CurrentAngle);
				
							float TotalRCS[2];
					
							viewAng[0] = MyPunch[0] - oldAng[0];
							viewAng[1] = MyPunch[1] - oldAng[1];

											TotalRCS[0] = viewAng[0] * 2.0f;
							TotalRCS[1] = viewAng[1] * 2.0f;
	
							CurrentAngle[0] -= TotalRCS[0];
							CurrentAngle[1] -= TotalRCS[1];

							NewPlayer.SetAngles(CurrentAngle);

							oldAng[0] = MyPunch[0];
							oldAng[1] = MyPunch[1];
					
							prevFired = shotsFired;
						} 
						else 
						{
							oldAng[0] = 0;
							oldAng[1] = 0;
							prevFired = 0;
						}
			
						Sleep(1);
					}			
				}
			}				
				
			if (autoTriggerEnabled)
			{
				Sleep(TriggerDelay);
				while (NewPlayer.GetCrosshairId() > 0 && PlayerNumber < 64 && PlayerNumber >= 0 && EntityList.GetTeam(PlayerNumber) != NewPlayer.GetTeam() && EntityList.IsDead(PlayerNumber) != true)
				{
					Click();
					
					if (!aimEnabled && rcsEnabled)
					{
						int shotsFired = NewPlayer.GetShotsFired();
						if (shotsFired > 1 && shotsFired >= prevFired)
						{
							float MyPunch[2];
							NewPlayer.GetPunch(MyPunch);

							float CurrentAngle[2];
							NewPlayer.GetAngles(CurrentAngle);
				
							float TotalRCS[2];
					
							viewAng[0] = MyPunch[0] - oldAng[0];
							viewAng[1] = MyPunch[1] - oldAng[1];

											TotalRCS[0] = viewAng[0] * 2.0f;
							TotalRCS[1] = viewAng[1] * 2.0f;
	
							CurrentAngle[0] -= TotalRCS[0];
							CurrentAngle[1] -= TotalRCS[1];

							NewPlayer.SetAngles(CurrentAngle);

							oldAng[0] = MyPunch[0];
							oldAng[1] = MyPunch[1];
					
							prevFired = shotsFired;
						} 
						else 
						{
							oldAng[0] = 0;
							oldAng[1] = 0;
							prevFired = 0;
						}
			
						Sleep(1);
					}			
				}	
			}
					
			if (!aimEnabled && rcsEnabled)
			{
				int shotsFired = NewPlayer.GetShotsFired();
				if (shotsFired > 1 && shotsFired >= prevFired)
				{
					float MyPunch[2];
					NewPlayer.GetPunch(MyPunch);

					float CurrentAngle[2];
					NewPlayer.GetAngles(CurrentAngle);
				
					float TotalRCS[2];
				
					viewAng[0] = MyPunch[0] - oldAng[0];
					viewAng[1] = MyPunch[1] - oldAng[1];

					TotalRCS[0] = viewAng[0] * 2.0f;
					TotalRCS[1] = viewAng[1] * 2.0f;
					
					CurrentAngle[0] -= TotalRCS[0];
					CurrentAngle[1] -= TotalRCS[1];

					NewPlayer.SetAngles(CurrentAngle);

					oldAng[0] = MyPunch[0];
					oldAng[1] = MyPunch[1];
					
					prevFired = shotsFired;
				} 
				else 
				{
					oldAng[0] = 0;
					oldAng[1] = 0;
					prevFired = 0;
				}
			
				Sleep(1);
			}			
		}
		else
		{
			TriggerThreadPaused = true;
			Sleep(500);
		}	
	}
}

void DrawBox(float x, float y, float width, float height, int* RGB)
{

	glLineWidth(3);
	glBegin(GL_LINE_LOOP);
	glColor4f(0, 0, 0, 1);
	glVertex2f(x - (width / 2), y); 
	glVertex2f(x - (width / 2), y - height); 
	glVertex2f(x + (width / 2), y - height); 
	glVertex2f(x + (width / 2), y);
	glEnd();
	glLineWidth(1);
	glBegin(GL_LINE_LOOP);
	glColor4f(RGB[0], RGB[1], RGB[2], 1);
	glVertex2f(x - (width / 2), y); 
	glVertex2f(x - (width / 2), y - height); 
	glVertex2f(x + (width / 2), y - height); 
	glVertex2f(x + (width / 2), y); 
	glEnd();
}

void DrawSnaplines(float x, float y, int* RGB)
{
	glLineWidth(3);
	glBegin(GL_LINES); 
	glColor4f(0, 0, 0, 1); 
	glVertex2f(x, y); 
	glVertex2f(SWidth / 2, SHeight);
	glEnd();
	glLineWidth(1);
	glBegin(GL_LINES); 
	glColor4f(RGB[0], RGB[1], RGB[2], 1); 
	glVertex2f(x, y);
	glVertex2f(SWidth / 2, SHeight); 
	glEnd();
}

//draw filled rectangle
void DrawFilledBox(float x, float y, float width, float height, int* RGB)
{
	glBegin(GL_QUADS);
	glColor4f(0, 0, 0, 1);
	glVertex2f(x - (width / 2) - 1, y + 1);
	glVertex2f(x - (width / 2) - 1, y - height - 1); 
	glVertex2f(x + (width / 2) + 1, y - height - 1); 
	glVertex2f(x + (width / 2) + 1, y + 1);
	glEnd();
	glBegin(GL_QUADS);
	glColor4f(RGB[0], RGB[1], RGB[2], 1);
	glVertex2f(x - (width / 2), y); 
	glVertex2f(x - (width / 2), y - height); 
	glVertex2f(x + (width / 2), y - height); 
	glVertex2f(x + (width / 2), y);
	glEnd();
}

void DrawCross(float x, float y, float width, float height, float LineWidth, int* RGB)
{
	glLineWidth(LineWidth + 2);
	glBegin(GL_LINES);
	glColor4f(0, 0, 0, 1);
	glVertex2f(x, y + height + 1);
	glVertex2f(x, y - height - 1);
	glVertex2f(x + width + 1, y);
	glVertex2f(x - width - 1, y);
	glEnd();

	glLineWidth(LineWidth);
	glBegin(GL_LINES);
	glColor4f(RGB[0], RGB[1], RGB[2], 1);
	glVertex2f(x, y + height);
	glVertex2f(x, y - height);
	glVertex2f(x + width, y);
	glVertex2f(x - width, y);
	glEnd();
}


LRESULT APIENTRY WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message) {
	case WM_CREATE:
	{
		MainHDC = GetDC(hWnd);
		SetupGL();
		return 0;
	}
	case WM_CLOSE:
	{
		DestroyWindow(hWnd);
	}
	case WM_DESTROY:
	{
		wglMakeCurrent(NULL, NULL);
		wglDeleteContext(MainHGLRC);
		DeleteDC(MainHDC);
		ReleaseDC(hWnd, MainHDC);
		PostQuitMessage(0);
	}

	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		BeginPaint(hWnd, &ps);
		glClear(GL_COLOR_BUFFER_BIT);
	
		Player me;
		Player players[64];

		me.dwBase = mem.Read<DWORD>(DwClient + DwLocalPlayer);
		ReadData(&me);
		for (int i = 1; i < 64; i++) {
			players[i].dwBase = mem.Read<DWORD>(DwClient + DwEntityList + i * 0x10);
			ReadData(&players[i]);
		}

		DWORD pointerGlow = mem.Read<DWORD>(DwClient + DwGlow);
		int objectCount = mem.Read<int>(DwClient + DwGlow + 0x4);
		if (pointerGlow != NULL) {
			for (int i = 0; i < objectCount; i++) {
				DWORD mObj = pointerGlow + i * 0x38;
				GlowObjectDefinition_t glowObj = mem.ReadNew<GlowObjectDefinition_t>(mObj);

				if (glowObj.pEntity != NULL) {
					int f_i = -1;
					for (int j = 1; j < 64; j++) {
						if (glowObj.pEntity == players[j].dwBase) {
							if (players[j].team != me.team && EntityList.IsDead(j) != true && EntityList.IsDormant(j) != true) {
									float PlayerPos[3];
									NewPlayer.GetPosition(PlayerPos);
									float EnemyPos[3];
									EntityList.GetPosition(j, EnemyPos);
									float EnemyXY[3];
									float distance = Get3D(PlayerPos[0], PlayerPos[1], PlayerPos[2], EnemyPos[0], EnemyPos[1], EnemyPos[2]);
									int width = 18100 / distance;
									int height = 36000 / distance;

									if (WorldToScreen(EnemyPos, EnemyXY))
									{
										int BoxColor[3] = { 255, 0, 0 };
										DrawBox(EnemyXY[0] - m_Rect.left, EnemyXY[1] - m_Rect.top, width, height, BoxColor);
										int SnapColor[3] = { 0, 122, 122 };
										DrawSnaplines(EnemyXY[0] - m_Rect.left, EnemyXY[1] - m_Rect.top, SnapColor);
										
										float HealthBarWidth = 2000.f / distance;
										int HealthBarBackColor[3] = { 255, 0, 0 };
										DrawFilledBox(EnemyXY[0] + (width / 2), EnemyXY[1] - m_Rect.top, HealthBarWidth, height, HealthBarBackColor);
										int HealthBarColor[3] = { 0, 255, 0 };
										DrawFilledBox(EnemyXY[0] + (width / 2), EnemyXY[1] - m_Rect.top, HealthBarWidth, (height / 100.f) * EntityList.GetHealth(j), HealthBarColor);
									}
								}

								float CrosshairPos2ScreenX = SWidth / 2;
								float CrosshairPos2ScreenY = SHeight / 2;
								float Punch2ScreenX = (SWidth / 358.f) * (NewPlayer.GetPunch1().x * 2);
								float Punch2ScreenY = (SHeight / 178.f) * (NewPlayer.GetPunch1().y * 2);
								CrosshairPos2ScreenX -= Punch2ScreenY;
								CrosshairPos2ScreenY += Punch2ScreenX;

								int CrossColor[3] = { 122, 122, 0 };
								DrawCross(CrosshairPos2ScreenX, CrosshairPos2ScreenY, 6, 6, 2, CrossColor);

							}
						}
					}
				}
			}

			SwapBuffers(MainHDC);
			EndPaint(hWnd, &ps);
		}
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}


DWORD WINAPI MainWindow(LPVOID PARAMS)
{
	Initiate();
	WNDCLASSEX WClass;
	MSG Msg;
	WClass.cbSize = sizeof(WNDCLASSEX);
	WClass.style = 0;
	WClass.lpfnWndProc = WndProc;
	WClass.cbClsExtra = 0;
	WClass.cbWndExtra = 0;
	WClass.hInstance = CurrentInstance;
	WClass.hIcon = NULL;
	WClass.hCursor = NULL;
	WClass.hbrBackground = CreateSolidBrush(RGB(0, 0, 0));
	WClass.lpszMenuName = NULL;
	WClass.lpszClassName = WName;
	WClass.hIconSm = NULL;
	if (!RegisterClassEx(&WClass))
	{
		std::cout << "RegisterClassEx";
		ExitThread(0);
	}
	EspHWND = CreateWindowEx(WS_EX_TRANSPARENT | WS_EX_TOPMOST | WS_EX_LAYERED, WName, WName, WS_POPUP | WS_VISIBLE | WS_MAXIMIZE, m_Rect.left, m_Rect.top - 1, SWidth, SHeight + 1, NULL, NULL, CurrentInstance, NULL);
	if (EspHWND == NULL)
	{
		std::cout << "EspHWND";
		ExitThread(0);
	}

	if (!SetLayeredWindowAttributes(EspHWND, RGB(0, 0, 0), 255, LWA_COLORKEY | LWA_ALPHA))
	{
		std::cout << "Layered";
		ExitThread(0);
	}

	BOOL IsEnabled;
	if (DwmIsCompositionEnabled(&IsEnabled) != S_OK)
	{
		std::cout << "CompEnabled";
		ExitThread(0);
	}

	if (!IsEnabled)
	{
		std::cout << "Enabled";
		ExitThread(0);
	}

	DWM_BLURBEHIND bb = { DWM_BB_ENABLE | DWM_BB_BLURREGION, true, CreateRectRgn(0, 0, -1, -1), true };
	if (DwmEnableBlurBehindWindow(EspHWND, &bb) != S_OK)
	{
		std::cout << "blur";
		ExitThread(0);
	}

	ShowWindow(EspHWND, 1);

	while (GetMessage(&Msg, NULL, 0, 0) > 0)
	{
		TranslateMessage(&Msg);
		DispatchMessage(&Msg);
	}
	ExitThread(0);
}

DWORD WINAPI RedrawLoop(LPVOID PARAMS)
{
	while (true)
	{
		ResizeWindow();
		InvalidateRect(EspHWND, NULL, false);
		Sleep(1);
	}
	ExitThread(0);
}

int whichKeyIsPressed() {
	while (true) {
		for (int i = 1; i < 255; i++) {
			if (GetAsyncKeyState(i) & 0x8000) {
				while (GetAsyncKeyState(i) & 0x8000) {
					Sleep(50);
				}
				return i;
			}
		}
		Sleep(10);
	}
}

float ReadFloat(char* szSection, char* szKey, float fltDefaultValue)
{
	LPCTSTR iniFile = TEXT(".\\Humblehack.ini");
	char szResult[255];
	char szDefault[255];
	float fltResult;
	sprintf(szDefault, "%f",fltDefaultValue);
	GetPrivateProfileString(szSection,  szKey, szDefault, szResult, 255, iniFile); 
	fltResult =  atof(szResult);
	return fltResult;
}

bool ReadBoolean(char* szSection, char* szKey, bool bolDefaultValue)
{
	LPCTSTR iniFile = TEXT(".\\Humblehack.ini");
	char szResult[255];
	char szDefault[255];
	bool bolResult;
	sprintf(szDefault, "%s", bolDefaultValue? "True" : "False");
	GetPrivateProfileString(szSection, szKey, szDefault, szResult, 255, iniFile); 
	bolResult =  (strcmp(szResult, "True") == 0 || 
	strcmp(szResult, "true") == 0) ? true : false;
	return bolResult;
}

	
int main(int argc, char *argv[])
{
	if (argc != 2)
	{
		std::cout << "Humblehack can only be launched via Humblehack Launcher!\n\n";
		return 1;
	}
	if (strlen(argv[1]) != 80)
	{
		std::cout << "Humblehack is only available for forum VIP users!\n\n";
		return 1;
	}
	std::cout << "Humblehack - ESP & Aimbot\n\n";
	std::cout << "Waiting for csgo.exe...";
	while (!mem.Attach("csgo.exe")) {
		std::cout << ".";
		Sleep(500);
	}
	modClient = mem.GetModule("client.dll");
	DwClient = modClient.dwBase;

	modEngine = mem.GetModule("engine.dll");
	DwEngine = modEngine.dwBase;
	
	Sleep(300);
	std::cout << "\nFound\n\n";

	std::cout << "Getting offsets...";	
	// Оффсеты
	
    DWORD lpStart = mem.FindPatternArr(modClient.dwBase, modClient.dwSize, "xxx????xx????xxxxx?", 19, 0x8D, 0x34, 0x85, 0x0, 0x0, 0x0, 0x0, 0x89, 0x15, 0x0, 0x0, 0x0, 0x0, 0x8B, 0x41, 0x8, 0x8B, 0x48, 0x0);
    DWORD lpP1 = mem.Read<DWORD>(lpStart + 3);
    BYTE lpP2 = mem.Read<BYTE>(lpStart + 18);
    DwLocalPlayer = (lpP1 + lpP2) - modClient.dwBase;

    DWORD elStart = mem.FindPatternArr(modClient.dwBase, modClient.dwSize, "x????xx?xxx", 11, 0x5, 0x0, 0x0, 0x0, 0x0, 0xC1, 0xE9, 0x0, 0x39, 0x48, 0x4);
    DWORD elP1 = mem.Read<DWORD>(elStart + 1);
    BYTE elP2 = mem.Read<BYTE>(elStart + 7);
    DwEntityList = (elP1 + elP2) - modClient.dwBase;


	DWORD gpStart = mem.FindPatternArr(modClient.dwBase, modClient.dwSize,  "x????xxxx????xx", 15, 0xE8, 0x0, 0x0, 0x0, 0x0, 0x83, 0xC4, 0x04, 0xB8, 0x0, 0x0, 0x0, 0x0, 0xC3, 0xCC);
	DwGlow = mem.Read<DWORD>(gpStart + 9) - modClient.dwBase;
	
	//DWORD epStart = mem.FindPatternArr(modEngine.dwBase, modEngine.dwSize, "xxxxxxxx????xxxxxxxxxx????xxxx????xxx", 37, 0xF3, 0x0F, 0x5C, 0xC1, 0xF3, 0x0F, 0x10, 0x15, 0x0, 0x0, 0x0, 0x0, 0x0F, 0x2F, 0xD0, 0x76, 0x04, 0xF3, 0x0F, 0x58, 0xC1, 0xA1, 0x0, 0x0, 0x0, 0x0, 0xF3, 0x0F, 0x11, 0x80, 0x0, 0x0, 0x0, 0x0, 0xD9, 0x46, 0x04);
	//DwEnginePointer = mem.Read<DWORD>(epStart + 22) - modEngine.dwBase;

	
	Sleep(300);
	std::cout << "\nDone\n\n";
	
	std::cout << "Ctrl+F1 To Edit Aimbot Settings\n\n";
	std::cout << "Ctrl+F2 To Show Aimbot Settings\n\n";
	std::cout << "Ctrl+F3 To Toggle IsDormant Checks\n\n";

	std::cout << "Hotkeys: \n";
	LPCTSTR iniFile = TEXT(".\\Humblehack.ini");
	//
	
	yesKey				= GetPrivateProfileInt((LPCTSTR)"Humblehack Hotkeys", (LPCTSTR)"Y Key", 0, iniFile);
    ESPVkeyCode     	= GetPrivateProfileInt((LPCTSTR)"Humblehack Hotkeys", (LPCTSTR)"ESP Toggle Key", 0, iniFile);
    AimVkeyCode     	= GetPrivateProfileInt((LPCTSTR)"Humblehack Hotkeys", (LPCTSTR)"Aimbot Toggle Key", 0, iniFile); 
	ToggleTrigVkeyCode  = GetPrivateProfileInt((LPCTSTR)"Humblehack Hotkeys", (LPCTSTR)"Trigger Toggle Key", 0, iniFile); 
    ForceAimVkeyCode 	= GetPrivateProfileInt((LPCTSTR)"Humblehack Hotkeys", (LPCTSTR)"Force Aim Key", 0, iniFile);
    TrigVkeyCode      	= GetPrivateProfileInt((LPCTSTR)"Humblehack Hotkeys", (LPCTSTR)"Trigger Key", 0, iniFile);
    RCSVkeyCode       	= GetPrivateProfileInt((LPCTSTR)"Humblehack Hotkeys", (LPCTSTR)"RCS Toggle Key", 0, iniFile);
	RadarVkeyCode		= GetPrivateProfileInt((LPCTSTR)"Humblehack Hotkeys", (LPCTSTR)"Radar Toggle Key", 0, iniFile);
    PanicVkeyCode     	= GetPrivateProfileInt((LPCTSTR)"Humblehack Hotkeys", (LPCTSTR)"Panic Key", 0, iniFile);
    enableBhop     		= GetPrivateProfileInt((LPCTSTR)"Humblehack Hotkeys", (LPCTSTR)"BHOP Enabled", 0, iniFile); 
    bhopVkeyCode 		= GetPrivateProfileInt((LPCTSTR)"Humblehack Hotkeys", (LPCTSTR)"    BHOP Key (NOT JUMP KEY)", 0, iniFile);
    jumpKey       		= GetPrivateProfileInt((LPCTSTR)"Humblehack Hotkeys", (LPCTSTR)"    Jump Key", 0, iniFile);
    enableExternal      = GetPrivateProfileInt((LPCTSTR)"Humblehack Hotkeys", (LPCTSTR)"External ESP Enabled", 0, iniFile);

    TriggerDelay      	= GetPrivateProfileInt((LPCTSTR)"Humblehack Settings", (LPCTSTR)"Trigger Delay", 0, iniFile);
    TargetBone       	= GetPrivateProfileInt((LPCTSTR)"Humblehack Settings", (LPCTSTR)"Target Bone", 0, iniFile);
    jumpScanCode       	= GetPrivateProfileInt((LPCTSTR)"Humblehack Settings", (LPCTSTR)"Jump Scan Key", 0, iniFile);
	
	SmoothAmount 		= ReadFloat("Humblehack Settings", "Smooth Amount", 0);
	PitchMinPunch		= ReadFloat("Humblehack Settings", "Pitch Min Punch", 0);
    PitchMaxPunch     	= ReadFloat("Humblehack Settings", "Pitch Max Punch", 0);
    YawMinPunch     	= ReadFloat("Humblehack Settings", "Yaw Min Punch", 0); 
	YawMaxPunch 		= ReadFloat("Humblehack Settings", "Yaw Max Punch", 0); 
	
	glowThickness 		= ReadFloat("Humblehack ESP Settings", "Glow Thickness", 0);
	showTeam 			= ReadBoolean("Humblehack ESP Settings", "Show Teammates", 0);
	
	if (PitchMinPunch == 0)
	{
		PitchMinPunch = 2;
	}
	if (PitchMaxPunch == 0)
	{
		PitchMaxPunch = 2;
	}
	if (YawMinPunch == 0)
	{
		YawMinPunch = 2;
	}	
	if (YawMaxPunch == 0)
	{
		YawMaxPunch = 2;
	}
	if (SmoothAmount == 0)
	{
		SmoothAmount = 7;
	}
	if (TriggerDelay == 0)
	{
		TriggerDelay = 1;
	}	
	if (TargetBone == 0)
	{
		TargetBone = 6;
	}	
	if (glowThickness == 0)
	{
		glowThickness = 0.6;
	}
	if (jumpScanCode  == 0)
	{
		jumpScanCode  = 57;
	}	
	if (yesKey  < 1)
	{
		yesKey  = 89;
	}

	WritePrivateProfileString("Humblehack Settings", "Smooth Amount", CStringify(SmoothAmount), iniFile);
	WritePrivateProfileString("Humblehack Settings", "Pitch Min Punch", CStringify(PitchMinPunch), iniFile);
	WritePrivateProfileString("Humblehack Settings", "Pitch Max Punch", CStringify(PitchMaxPunch), iniFile);
	WritePrivateProfileString("Humblehack Settings", "Yaw Min Punch", CStringify(YawMinPunch), iniFile);
	WritePrivateProfileString("Humblehack Settings", "Yaw Max Punch", CStringify(YawMaxPunch), iniFile);
	WritePrivateProfileString("Humblehack Settings", "Target Bone", CStringify(TargetBone), iniFile);	
	WritePrivateProfileString("Humblehack Settings", "Trigger Delay", CStringify(TriggerDelay), iniFile);
	WritePrivateProfileString("Humblehack Settings", "Jump Scan Key", CStringify(jumpScanCode), iniFile);	
	WritePrivateProfileString("Humblehack Settings", "", "", iniFile);	
	WritePrivateProfileString("Humblehack Settings", "", "", iniFile);	
	WritePrivateProfileString("Humblehack Settings", "", "", iniFile);
	WritePrivateProfileString("Humblehack ESP Settings", "Glow Thickness",  CStringify(glowThickness), iniFile);
	WritePrivateProfileString("Humblehack ESP Settings", "", "", iniFile);	
	WritePrivateProfileString("Humblehack ESP Settings", "", "", iniFile);	
	WritePrivateProfileString("Humblehack ESP Settings", "", "", iniFile);
	
	if (yesKey < 1)
	{
		std::cout << "Please Press Your Y Key.";
		yesKey = whichKeyIsPressed();
		std::cout << "\n";
	}		
	
	if (ESPVkeyCode < 1)
	{
		std::cout << "Toggle ESP: ";
		ESPVkeyCode = whichKeyIsPressed();
		std::cout << ESPVkeyCode << "\n";
	}
	else
		std::cout << "Toggle ESP: " << ESPVkeyCode << "\n";
	
	if (AimVkeyCode < 1)
	{
		std::cout << "Toggle Aimbot: ";
		AimVkeyCode = whichKeyIsPressed();
		std::cout << AimVkeyCode << "\n";
	}
	else
		std::cout << "Toggle Aimbot: " << AimVkeyCode << "\n";
	
	if (ForceAimVkeyCode < 1)
	{
		std::cout << "Force Aim: ";
		ForceAimVkeyCode = whichKeyIsPressed();
		std::cout << ForceAimVkeyCode << "\n";
	}
	else
		std::cout << "Force Aim: " << ForceAimVkeyCode << "\n";
	
	if (TrigVkeyCode < 1)
	{
		std::cout << "Trigger Fire: ";
		TrigVkeyCode = whichKeyIsPressed();
		std::cout << TrigVkeyCode << "\n";
	}
	else
		std::cout << "Trigger Fire: " << TrigVkeyCode << "\n";

	if (ToggleTrigVkeyCode < 1)
	{
		std::cout << "Toggle Trigger Fire: ";
		ToggleTrigVkeyCode = whichKeyIsPressed();
		std::cout << ToggleTrigVkeyCode << "\n";
	}
	else
		std::cout << "Toggle Trigger Fire: " << ToggleTrigVkeyCode << "\n";
	
	if (RCSVkeyCode < 1)
	{
		std::cout << "Toggle RCS: ";
		RCSVkeyCode = whichKeyIsPressed();
		std::cout << RCSVkeyCode << "\n";
	}
	else
		std::cout << "Toggle RCS: " << RCSVkeyCode << "\n";
	
	if (RadarVkeyCode < 1)
	{
		std::cout << "Radar Key: ";
		RadarVkeyCode = whichKeyIsPressed();
		std::cout << RadarVkeyCode << "\n";	
	}
	else
		std::cout << "Radar Key: " << RadarVkeyCode << "\n";
	
	if (PanicVkeyCode < 1)
	{
		std::cout << "Panic Key: ";
		PanicVkeyCode = whichKeyIsPressed();
		std::cout << PanicVkeyCode << "\n";
	}
	else
		std::cout << "Panic Key: " << PanicVkeyCode << "\n";
	
	if (enableBhop < 1)
	{
		std::cout << "Bhop Enabled (Y/N): ";
		enableBhop = whichKeyIsPressed();
		std::cout << enableBhop << "\n";
	}
	else
		std::cout << "Bhop Enabled (Y/N): "  << enableBhop << "\n";

	if (enableBhop == yesKey) {
		if (bhopVkeyCode < 1)
		{
			std::cout << "Bhop Key (NOT JUMP KEY): ";
			bhopVkeyCode = whichKeyIsPressed();
			std::cout << bhopVkeyCode << "\n";
		}
		else
			std::cout << "Bhop Key (NOT JUMP KEY): " << bhopVkeyCode << "\n";

		if (jumpKey < 1)
		{
			std::cout << "Jump Key: ";
			jumpKey = whichKeyIsPressed();
			std::cout << jumpKey << "\n";
		}
		else
			std::cout << "Jump Key: " << jumpKey << "\n";
		
		std::cout << "Remember to change the scan key in Ctrl + F1 or it will not work.";
		std::cout << "\nA link to each scan key is provided on the main thread.\n";
	}
	
	if (enableExternal < 1)
	{
		std::cout << "External ESP Enabled (Y/N): ";
		enableExternal = whichKeyIsPressed();
		std::cout << enableExternal << "\n";
	}
	else
		std::cout << "External ESP Enabled (Y/N): "  << enableExternal << "\n";
	
	if (enableExternal == yesKey) {		
		std::cout << "You must be in windowed mode for this to work.\n";
	}

	//
	
	WritePrivateProfileString("Humblehack Hotkeys", "Y Key", CStringify(yesKey), iniFile);
	WritePrivateProfileString("Humblehack Hotkeys", "ESP Toggle Key", CStringify(ESPVkeyCode), iniFile);
    WritePrivateProfileString("Humblehack Hotkeys", "Aimbot Toggle Key", CStringify(AimVkeyCode), iniFile);
    WritePrivateProfileString("Humblehack Hotkeys", "RCS Toggle Key", CStringify(RCSVkeyCode), iniFile);
    WritePrivateProfileString("Humblehack Hotkeys", "Radar Toggle Key", CStringify(RadarVkeyCode), iniFile);
    WritePrivateProfileString("Humblehack Hotkeys", "Trigger Toggle Key", CStringify(ToggleTrigVkeyCode), iniFile);	
    WritePrivateProfileString("Humblehack Hotkeys", "Force Aim Key", CStringify(ForceAimVkeyCode), iniFile);
    WritePrivateProfileString("Humblehack Hotkeys", "Trigger Key", CStringify(TrigVkeyCode), iniFile);
    WritePrivateProfileString("Humblehack Hotkeys", "Panic Key", CStringify(PanicVkeyCode), iniFile);
    WritePrivateProfileString("Humblehack Hotkeys", "BHOP Enabled", CStringify(enableBhop), iniFile);
	WritePrivateProfileString("Humblehack Hotkeys", "    BHOP Key (NOT JUMP KEY)", CStringify(bhopVkeyCode), iniFile);
	WritePrivateProfileString("Humblehack Hotkeys", "    Jump Key", CStringify(jumpKey), iniFile);
    WritePrivateProfileString("Humblehack Hotkeys", "External ESP Enabled", CStringify(enableExternal), iniFile);	
	WritePrivateProfileString("Humblehack Hotkeys", "", "", iniFile);	
	WritePrivateProfileString("Humblehack Hotkeys", "", "", iniFile);	
	WritePrivateProfileString("Humblehack Hotkeys", "", "", iniFile);	
	std::cout << "\n";

	GetWindowRect(FindWindow(NULL, "Counter-Strike: Global Offensive"), &m_Rect);
	GetClientRect(FindWindow(NULL, "Counter-Strike: Global Offensive"), &c_Rect);

	CreateThread(0, 0x1000, &AB, 0, 0, 0);
	CreateThread(0, 0x1001, &TB, 0, 0, 0);

	if (enableExternal == yesKey)
	{
		CreateThread(0, 0x1002, &MainWindow, 0, 0, 0);
		CreateThread(0, 0x1001, &RedrawLoop, 0, 0, 0);
	}
	
	Player me;
	Player players[64];

	while (!GetAsyncKeyState(PanicVkeyCode)) {
		
		if (enableBhop == yesKey) {
			
			if (GetAsyncKeyState(bhopVkeyCode)) {
				while (GetAsyncKeyState(bhopVkeyCode)) {
					if (NewPlayer.GetZVelocity() == 0)
					{
						Space();
					}
				}
			}
		}

		if (GetAsyncKeyState(ESPVkeyCode) & 0x8000) {
			while (GetAsyncKeyState(ESPVkeyCode) & 0x8000) {
				Sleep(50);
			}
			glowEnabled = !glowEnabled;
			std::cout << "Glow ESP is now ";
			if (glowEnabled) {
				std::cout << "enabled\n";
			}
			else {
				std::cout << "disabled\n";
			}
		}

		if (GetAsyncKeyState(AimVkeyCode) & 0x8000) {
			while (GetAsyncKeyState(AimVkeyCode) & 0x8000) {
				Sleep(50);
			}
			aimEnabled = !aimEnabled;
			std::cout << "Aimbot is now ";
			if (aimEnabled) {
				std::cout << "enabled\n";
			}
			else {
				std::cout << "disabled\n";
			}
		}
		
		if (GetAsyncKeyState(RCSVkeyCode) & 0x8000) {
			while (GetAsyncKeyState(RCSVkeyCode) & 0x8000) {
				Sleep(50);
			}
			rcsEnabled = !rcsEnabled;
			std::cout << "RCS is now ";
			if (rcsEnabled) {
				std::cout << "enabled\n";
			}
			else {
				std::cout << "disabled\n";
			}
		}
	
	
		if (GetAsyncKeyState(RadarVkeyCode) & 0x8000) {
			while (GetAsyncKeyState(RadarVkeyCode) & 0x8000) {
				Sleep(50);
			}
			radarEnabled = !radarEnabled;
			std::cout << "Radar is now ";
			if (radarEnabled) {
				std::cout << "enabled\n";
			}
			else {
				std::cout << "disabled\n";
			}
		}
		
		if (GetAsyncKeyState(ToggleTrigVkeyCode) & 0x8000) {
			while (GetAsyncKeyState(ToggleTrigVkeyCode) & 0x8000) {
				Sleep(50);
			}
			autoTriggerEnabled = !autoTriggerEnabled;
			std::cout << "Auto Trigger is now ";
			if (autoTriggerEnabled) {
				std::cout << "enabled\n";
			}
			else {
				std::cout << "disabled\n";
			}
		}
		
		if (GetAsyncKeyState(17) < 0 && GetAsyncKeyState(114) < 0) {
			while (GetAsyncKeyState(17) < 0 && GetAsyncKeyState(114) < 0) {
				Sleep(50);
			}
			isDormantCheck = !isDormantCheck;
			std::cout << "Dormant Check is now ";
			if (isDormantCheck) {
				std::cout << "enabled\n";
			}
			else {
				std::cout << "disabled\n";
			}
		}
		
		
		if (GetAsyncKeyState(17) < 0 && GetAsyncKeyState(112) < 0)
		{
			while (GetAsyncKeyState(17) < 0 && GetAsyncKeyState(112) < 0)
			{
				Sleep(100);
			}
			std::cout << "\n\nConfigure Manual Options...";
			
			aimEnabled = false;
			triggerEnabled = false;
			
			std::cout << "\nWaiting for threads to enter paused state";
			
			while (!ThreadPaused && !TriggerThreadPaused)
			{
				std::cout << ".";
				Sleep(500);
			}
			
			std::cout << "\n\nDone.";
			std::cout << "\nOptions: ";
			std::cout << "\n- Smoothing factor (float, Default 20.0) = ";
			
			cin.sync();
			float tempSmoothWriteCount;
			if (cin >> tempSmoothWriteCount)
			{
				SmoothAmount = tempSmoothWriteCount;
				
			}
			else
			{
				std::cout << "\nInvalid Value. Keeping default...";
				cin.clear();
				cin.ignore(10000, '\n');
			}
			std::cout << "\n- Minimum RCS pitch compensation scale (float, Default 2.0) = ";
			cin.sync();
			float tempPitchMinPunch;
			if (cin >> tempPitchMinPunch)
			{
				PitchMinPunch = tempPitchMinPunch;
				
			}
			else
			{
				std::cout << "\nInvalid Value. Keeping default...";
				cin.clear();
				cin.ignore(10000, '\n');
			}
			std::cout << "\n- Maximum RCS pitch compensation scale (float, Default 2.0) = ";
			cin.sync();
			float tempPitchMaxPunch;
			if (cin >> tempPitchMaxPunch)
			{
				PitchMaxPunch = tempPitchMaxPunch;
				
			}
			else
			{
				std::cout << "\nInvalid Value. Keeping default...";
				cin.clear();
				cin.ignore(10000, '\n');
			}
			std::cout << "\n- Minimum RCS yaw compensation scale (float, Default 2.0) = ";
			cin.sync();
			float tempYawMinPunch;
			if (cin >> tempYawMinPunch)
			{
				YawMinPunch = tempYawMinPunch;
				
			}
			else
			{
				std::cout << "\nInvalid Value. Keeping default...";
				cin.clear();
				cin.ignore(10000, '\n');
			}
			std::cout << "\n- Maximum RCS yaw compensation scale (float, Default 2.0) = ";
			cin.sync();
			float tempYawMaxPunch;
			if (cin >> tempYawMaxPunch)
			{
				YawMaxPunch = tempYawMaxPunch;
				
			}
			else
			{
				std::cout << "\nInvalid Value. Keeping default...";
				cin.clear();
				cin.ignore(10000, '\n');
			}
			std::cout << "\n- Bone number to target(int, Default 10) = ";
			cin.sync();
			int tempboneid;
			if (cin >> tempboneid)
			{
				TargetBone = tempboneid;
				
			}
			else
			{
				std::cout << "\nInvalid Value. Keeping default...";
				cin.clear();
				cin.ignore(10000, '\n');
			}
			
			std::cout << "\n- Trigger Delay (int, In Milliseconds, Default 1) = ";
			cin.sync();
			int tempTriggerDelay;
			if (cin >> tempTriggerDelay)
			{
				TriggerDelay = tempTriggerDelay;
				
			}
			else
			{
				std::cout << "\nInvalid Value. Keeping default...";
				cin.clear();
				cin.ignore(10000, '\n');
			}

			std::cout << "\n- Jump Scan Key (int) = ";
			cin.sync();
			int tempScanCode;
			if (cin >> tempScanCode)
			{
				jumpScanCode = tempScanCode;
				
			}
			else
			{
				std::cout << "\nInvalid Value. Keeping default...";
				cin.clear();
				cin.ignore(10000, '\n');
			}				

			std::cout << "\nDone. Threads should be restored.\n";	

			WritePrivateProfileString("Humblehack Settings", "Smooth Amount", CStringify(SmoothAmount), iniFile);
			WritePrivateProfileString("Humblehack Settings", "Pitch Min Punch", CStringify(PitchMinPunch), iniFile);
			WritePrivateProfileString("Humblehack Settings", "Pitch Max Punch", CStringify(PitchMaxPunch), iniFile);
			WritePrivateProfileString("Humblehack Settings", "Yaw Min Punch", CStringify(YawMinPunch), iniFile);
			WritePrivateProfileString("Humblehack Settings", "Yaw Max Punch", CStringify(YawMaxPunch), iniFile);
			WritePrivateProfileString("Humblehack Settings", "Target Bone", CStringify(TargetBone), iniFile);	
			WritePrivateProfileString("Humblehack Settings", "Trigger Delay", CStringify(TriggerDelay), iniFile);
			WritePrivateProfileString("Humblehack Settings", "Jump Scan Key", CStringify(jumpScanCode), iniFile);			
			
			aimEnabled = true;
			triggerEnabled = true;
			
		}
		
		if (GetAsyncKeyState(17) < 0 && GetAsyncKeyState(113) < 0)
		{
			while (GetAsyncKeyState(17) < 0 && GetAsyncKeyState(113) < 0)
			{
				Sleep(100);
			}
			std::cout << "\n\nCurrent settings: " << endl << "- Smoothing factor (float) = " << SmoothAmount << endl << "- Minimum RCS pitch compensation scale (float) = " << PitchMinPunch << endl << "- Maximum RCS pitch compensation scale (float) = " << PitchMaxPunch << endl << "- Minimum RCS yaw compensation scale (float) = " << YawMinPunch << endl << "- Maximum RCS yaw compensation scale (float) = " << YawMaxPunch << endl << "- Bone number to target(int) = " << TargetBone << endl;
		}	
		
		if (glowEnabled) {
                                                                                                                           
			me.dwBase = mem.Read<DWORD>(DwClient + DwLocalPlayer);
			ReadData(&me);
			for (int i = 1; i < 64; i++) {
				players[i].dwBase = mem.Read<DWORD>(DwClient + DwEntityList + i * 0x10);
				ReadData(&players[i]);
			}

			DWORD pointerGlow = mem.Read<DWORD>(DwClient + DwGlow);
			int objectCount = mem.Read<int>(DwClient + DwGlow + 0x4);
			if (pointerGlow != NULL) {
				for (int i = 0; i < objectCount; i++) {
		
					DWORD mObj = pointerGlow + i * 0x38;
					GlowObjectDefinition_t glowObj = mem.ReadNew<GlowObjectDefinition_t>(mObj);
					
					
					if (glowObj.pEntity != NULL) {
						int f_i = -1;
						for (int j = 1; j < 64; j++) {
							if (glowObj.pEntity == players[j].dwBase) {
								int r, g, b;
								if (players[j].team == me.team) {
									r = 0;
									g = 0;
									b = 255;
								}
								else if (players[j].dwBase == EntityList.GetBaseEntity(NewPlayer.GetCrosshairId())) {
									r = 255;
									g = 215;
									b = 0;
								}
								else if (EntityList.GetFlash(j))
								{
									r = 255;
									g = 0;
									b = 255;
								}
								else {
									r = 255;
									g = 0;
									b = 0;
								}
								
								if (isDormantCheck)	{
									if (EntityList.IsDormant(j) == false) {
										mem.WriteNew<float>(mObj + 0x4, r);
										mem.WriteNew<float>(mObj + 0x8, g);
										mem.WriteNew<float>(mObj + 0xC, b);
										mem.WriteNew<float>(mObj + 0x10, glowThickness);
										mem.WriteNew<bool>(mObj + 0x24, true);
										mem.WriteNew<bool>(mObj + 0x25, false);																		
									}
								}
								else {
									mem.WriteNew<float>(mObj + 0x4, r);
									mem.WriteNew<float>(mObj + 0x8, g);
									mem.WriteNew<float>(mObj + 0xC, b);
									mem.WriteNew<float>(mObj + 0x10, glowThickness);
									mem.WriteNew<bool>(mObj + 0x24, true);
									mem.WriteNew<bool>(mObj + 0x25, false);									
								}
							}
						}
					}
				}
			}
		}
		
		if (radarEnabled) {
			me.dwBase = mem.Read<DWORD>(DwClient + DwLocalPlayer);
			ReadData(&me);
			for (int i = 1; i < 64; i++) {
				players[i].dwBase = mem.Read<DWORD>(DwClient + DwEntityList + i * 0x10);
				ReadData(&players[i]);
			}
			DWORD pointerGlow = mem.Read<DWORD>(DwClient + DwGlow);
			int objectCount = mem.Read<int>(DwClient + DwGlow + 0x4);
			if (pointerGlow != NULL) {
				for (int i = 0; i < objectCount; i++) {
					
					DWORD mObj = pointerGlow + i * 0x38;
					GlowObjectDefinition_t glowObj = mem.ReadNew<GlowObjectDefinition_t>(mObj);
					
					if (glowObj.pEntity != NULL) {
						int f_i = -1;
						for (int j = 1; j < 64; j++) {
							if (glowObj.pEntity == players[j].dwBase) {
								if (players[j].team != me.team) {
									mem.WriteNew<int>(players[j].dwBase + DwSpotted, 1);
								}
							}
						}
					}
				}
			}
		}
		
	}

	return 0;
}
