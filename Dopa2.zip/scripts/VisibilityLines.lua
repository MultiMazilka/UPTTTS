local VL = {}

local whereAt = { "Awareness", "Visibility Lines" }
VL.enabled = Menu.AddOption(whereAt, "Enabled", "Enables the drawing of visiblity lines.")
VL.teammates = Menu.AddOption(whereAt, "Show Teammates", "Shows the visibility lines of your teammates.")
VL.enemies = Menu.AddOption(whereAt, "Show Enemies", "Shows the visibility lines of your enemies.")
VL.me = Menu.AddOption(whereAt, "Show Me", "Shows the visibility lines of your hero.")
VL.time = Menu.AddOption(whereAt, "Time", "How long to keep the lines drawn.", 0, 60, 10)
VL.length = Menu.AddOption(whereAt, "Length Between", "How long the distance between each point can be.", 100, 500, 10)
VL.points = {}

function VL.AddPoint(hero, pos, team)
    if not VL.points[hero] then
        VL.points[hero] = {}
    end

    local heroPoints = VL.points[hero]

    if #heroPoints > 0 then
        -- Bail if the last point is too close.
        if (pos - heroPoints[#heroPoints].pos):Length2D() < Menu.GetValue(VL.length) then return end
    end

    local newPoint = {}

    newPoint.pos = pos
    newPoint.team = team 
    newPoint.endTime = os.clock() + Menu.GetValue(VL.time)

    table.insert(heroPoints, newPoint)
end

function VL.ClearOldPoints(hero)
    if not VL.points[hero] then
        VL.points[hero] = {}
        return
    end

    local heroPoints = VL.points[hero]

    if #heroPoints == 0 then
        VL.points[hero] = nil
        return
    end

    for k, point in ipairs(heroPoints) do
        if os.clock() > point.endTime then
            table.remove(heroPoints, k)
        end
    end
end

--
-- Callbacks.
--
function VL.OnUpdate()
    local myHero = Heroes.GetLocal()

    if not myHero then return end

    for i = 1, Heroes.Count() do
        local hero = Heroes.Get(i)

        VL.ClearOldPoints(hero)

        if Entity.IsSameTeam(myHero, hero) then
            if NPC.IsVisible(hero) then
                if hero == myHero and Menu.IsEnabled(VL.me) then
                    VL.AddPoint(hero, NPC.GetAbsOrigin(hero), 1) 
                elseif hero ~= myHero and Menu.IsEnabled(VL.teammates) then
                    VL.AddPoint(hero, NPC.GetAbsOrigin(hero), 2)
                end
            end
        else
            if Menu.IsEnabled(VL.enemies) then
                VL.AddPoint(hero, NPC.GetAbsOrigin(hero), 3)
            end
        end
    end
end

function VL.OnDraw()
    if not Menu.IsEnabled(VL.enabled) then return end

    if not Heroes.GetLocal() then return end

    for k, heroPoints in pairs(VL.points) do
        local lastPosX = nil
        local lastPosY = nil
        local lastPos = nil

        for i, point in ipairs(heroPoints) do
            local timeLeft = math.max(point.endTime - os.clock(), 0)
            local alpha = math.floor(255 * math.min(timeLeft / 5, 1))

            if point.team == 1 then
                Renderer.SetDrawColor(255, 228, 181, alpha)
            elseif point.team == 2 then
                Renderer.SetDrawColor(100, 149, 237, alpha)
            else
                Renderer.SetDrawColor(220, 20, 60, alpha)
            end

            local pos = point.pos
            local x, y, visible = Renderer.WorldToScreen(pos)

            if visible then
                Renderer.DrawFilledRect(x - 1, y - 1, 3, 3)

                if lastPos and (lastPos - pos):Length2D() < Menu.GetValue(VL.length) + 100 then
                    Renderer.DrawLine(lastPosX, lastPosY, x, y)
                end

                lastPos = pos
                lastPosX = x
                lastPosY = y
            else
                lastPos = nil
            end
        end
    end
end

return VL

